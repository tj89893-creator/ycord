# ycord · plugin de rendimiento para Vencord

Plugin ligero que reduce el trabajo de renderizado y los eventos innecesarios
de Discord. No envía datos, no toca tu cuenta y no hace peticiones de red.

## Qué hace

### Parches de renderizado

| Parche | Efecto |
| --- | --- |
| `canAnimate` | Fuerza `false` en todos los componentes que consultan si pueden animar: avatares animados, GIFs, emojis, banners y decoraciones. |
| `dotCycle` | Desactiva la animación de los puntos de «escribiendo…». |
| Emoji de estado | Detiene los emojis animados del estado personalizado. |
| Banner de servidor | Detiene los banners animados. |
| Gradientes de rol | Detiene los degradados animados en chat y lista de miembros. |
| Placas de perfil | Detiene las placas animadas. |

### Eventos

- **Typing:** ignora `TYPING_START`, `TYPING_START_LOCAL`, `TYPING_STOP` y
  `TYPING_STOP_LOCAL`. En servidores grandes esto evita decenas de re-renders
  por minuto.
- **Presencia (opcional):** puede congelar `PRESENCE_UPDATE` y
  `PRESENCE_UPDATES`. Los estados dejan de refrescarse, pero se ahorran eventos.
- **Analytics:** anula `track` y `trackWithMetadata` del módulo de analíticas de
  Discord si está presente. Si Discord cambia ese módulo, el plugin sigue
  funcionando sin ese extra.

## Ajustes

En **Ajustes → Vencord → Plugins → ycord**:

- **Ignorar eventos de «escribiendo…»** — activado por defecto.
- **Anular eventos analíticos** — activado por defecto; requiere reiniciar.
- **Congelar presencia** — desactivado por defecto; opcional y agresivo.

Los parches de renderizado se aplican al activar el plugin y **requieren
reiniciar Discord** para entrar en vigor.

## Instalación

Desde la carpeta principal del paquete:

```bat
install-ycord.cmd
```

O manualmente:

1. Copia esta carpeta a `Vencord\src\userplugins\ycord`.
2. Ejecuta en la carpeta de Vencord:

```bat
pnpm build
pnpm inject
```

3. Reinicia Discord y activa **ycord**.

## Compatibilidad

Desactiva estos plugins si los tienes, porque hacen lo contrario o parchean lo
mismo:

- **AlwaysAnimate** (fuerza animaciones).
- **NoTypingAnimation** (duplica el parche de `dotCycle`).
- Cualquier plugin que fuerce animaciones o efectos de perfil.

El tema **ycord** es el complemento visual: quita blur, sombras y animaciones
CSS. Se pueden usar juntos.

## Optimización interna

- Sin `setInterval`, `setTimeout`, `MutationObserver` ni polling.
- Sin peticiones de red ni telemetría.
- Sin dependencias externas.
- El único trabajo en runtime es un filtro booleano por evento del dispatcher.
- Los parches se compilan dentro del bundle de Vencord; no añaden código en
  tiempo de ejecución más allá del filtro.

## Desinstalar

```bat
uninstall-ycord.cmd
```

O borra `Vencord\src\userplugins\ycord`, recompila y vuelve a inyectar.

## Aviso

Vencord y los client mods no están oficialmente soportados por Discord. Úsalo
bajo tu responsabilidad y solo en tu propia cuenta. Este plugin no automatiza
acciones, no envía mensajes y no accede a tu token.
