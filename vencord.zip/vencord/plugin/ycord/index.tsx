/*
 * ycord · plugin de rendimiento para Vencord
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * No envía datos, no toca la cuenta y no hace peticiones de red.
 * Solo reduce trabajo de renderizado y eventos innecesarios.
 */

import { definePluginSettings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { findByProps } from "@webpack";
import { FluxDispatcher } from "@webpack/common";

const settings = definePluginSettings({
    blockTyping: {
        type: OptionType.BOOLEAN,
        description: "Ignorar los eventos de «escribiendo…» para evitar re-renders y repintados en canales grandes.",
        default: true
    },
    blockAnalytics: {
        type: OptionType.BOOLEAN,
        description: "Anular los eventos analíticos de Discord. No afecta a tu cuenta ni a los mensajes.",
        default: true,
        restartNeeded: true
    },
    blockPresence: {
        type: OptionType.BOOLEAN,
        description: "Congelar las actualizaciones de presencia (estados) en servidores grandes. Opcional: los estados dejan de refrescarse.",
        default: false
    }
});

let originalDispatch: typeof FluxDispatcher.dispatch | undefined;
let dispatchPatched = false;

function shouldDropEvent(event: any) {
    if (settings.store.blockTyping) {
        switch (event?.type) {
            case "TYPING_START":
            case "TYPING_START_LOCAL":
            case "TYPING_STOP":
            case "TYPING_STOP_LOCAL":
                return true;
        }
    }

    if (settings.store.blockPresence) {
        switch (event?.type) {
            case "PRESENCE_UPDATE":
            case "PRESENCE_UPDATES":
                return true;
        }
    }

    return false;
}

function disableAnalytics() {
    try {
        const analytics = findByProps("trackWithMetadata", "track") as any;
        if (!analytics) return;

        for (const key of ["track", "trackWithMetadata"]) {
            if (typeof analytics[key] === "function") {
                analytics[key] = () => void 0;
            }
        }
    } catch {
        // Si Discord cambia el módulo, el plugin sigue funcionando sin este extra.
    }
}

export default definePlugin({
    name: "ycord",
    description: "Modo rendimiento: corta animaciones internas, decoraciones y eventos de typing. Sin red, sin telemetría y sin tocar tu cuenta.",
    tags: ["Utility", "Appearance", "Accessibility"],
    authors: [{ name: "ycord", id: 0n }],
    settings,

    patches: [
        {
            // Discord decide con canAnimate si anima avatares, GIFs, emojis,
            // banners y decoraciones. Forzarlo a false apaga todo de una vez.
            find: "canAnimate:",
            all: true,
            noWarn: true,
            replacement: {
                match: /canAnimate:.+?([,}].*?\))/g,
                replace: (match, rest) => {
                    if (/}=.+/.test(rest)) return match;
                    return `canAnimate:!1${rest}`;
                }
            }
        },
        {
            // Puntos de "escribiendo…": animación intensiva en CPU.
            find: "dotCycle",
            noWarn: true,
            replacement: {
                match: /focused:(\i)/g,
                replace: (_, focused) => `_focused:${focused}=false`
            }
        },
        {
            // Emoji de estado personalizado animado.
            find: "#{intl::GUILD_OWNER}),children:",
            noWarn: true,
            replacement: {
                match: /(\.CUSTOM_STATUS.+?animateEmoji:)\i/,
                replace: "$1!1"
            }
        },
        {
            // Banner de servidor animado.
            find: "#{intl::DISCOVERABLE_GUILD_HEADER_PUBLIC_INFO}",
            noWarn: true,
            replacement: {
                match: /(guildBanner:\i,animate:)\i(?=}\):null)/,
                replace: "$1!1"
            }
        },
        {
            // Gradientes de rol animados en el chat.
            find: "=!1,contentOnly:",
            noWarn: true,
            replacement: {
                match: /animate:\i/,
                replace: "animate:!1"
            }
        },
        {
            // Gradientes de rol animados en la lista de miembros.
            find: '="left",className:',
            noWarn: true,
            replacement: {
                match: /,animateGradient:/,
                replace: ",animateGradient:!1,_oldAnimateGradient:"
            }
        },
        {
            // Placas de perfil animadas.
            find: ".MINI_PREVIEW,[",
            noWarn: true,
            replacement: {
                match: /animate:\i,loop:(?=!0===)/,
                replace: "animate:false,loop:false,_loop:"
            }
        }
    ],

    start() {
        if (settings.store.blockAnalytics) disableAnalytics();

        if (!settings.store.blockTyping && !settings.store.blockPresence) return;

        try {
            originalDispatch = FluxDispatcher.dispatch;
            FluxDispatcher.dispatch = function (event: any) {
                if (shouldDropEvent(event)) return;
                return originalDispatch!.call(FluxDispatcher, event);
            };
            dispatchPatched = true;
        } catch {
            // Si el dispatcher no permite el reemplazo, se ignora.
        }
    },

    stop() {
        if (!dispatchPatched) return;

        try {
            if (originalDispatch) FluxDispatcher.dispatch = originalDispatch;
        } catch {
            // Nada que restaurar.
        }

        dispatchPatched = false;
        originalDispatch = undefined;
    }
});
