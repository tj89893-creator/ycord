@echo off
setlocal EnableExtensions
title ycord rendimiento - desinstalador
color 0B

echo.
echo   ============================================
echo    ycord - rendimiento para Discord
echo    desinstalar
echo   ============================================
echo.

set "VC=%~1"
if not defined VC set "VC=%VENCORD_DIR%"

if not defined VC if exist "%USERPROFILE%\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Vencord"
if not defined VC if exist "%USERPROFILE%\Documents\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Documents\Vencord"
if not defined VC if exist "%USERPROFILE%\Desktop\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Desktop\Vencord"
if not defined VC if exist "C:\Vencord\src\Vencord.ts" set "VC=C:\Vencord"
if not defined VC if exist "%LOCALAPPDATA%\Vencord\src\Vencord.ts" set "VC=%LOCALAPPDATA%\Vencord"

set "REMOVED_PLUGIN=0"

if defined VC if exist "%VC%\src\userplugins\ycord" (
    rd /S /Q "%VC%\src\userplugins\ycord"
    if exist "%VC%\src\userplugins\ycord" (
        echo [ERROR] No se pudo borrar "%VC%\src\userplugins\ycord"
    ) else (
        echo [OK] Plugin eliminado de "%VC%\src\userplugins\ycord"
        set "REMOVED_PLUGIN=1"
    )
)

if exist "%APPDATA%\Vencord\themes\ycord.theme.css" (
    del /Q "%APPDATA%\Vencord\themes\ycord.theme.css"
    if exist "%APPDATA%\Vencord\themes\ycord.theme.css" (
        echo [ERROR] No se pudo borrar el tema.
    ) else (
        echo [OK] Tema eliminado de "%APPDATA%\Vencord\themes"
    )
)

if "%REMOVED_PLUGIN%"=="1" (
    echo.
    echo El plugin sigue dentro del bundle compilado hasta que recompiles Vencord.
    choice /C SN /N /M "Recompilar y aplicar ahora? [S/N] "
    if errorlevel 2 goto :manual
    echo.
    echo Cerrando Discord...
    taskkill /F /IM Discord.exe >nul 2>nul
    taskkill /F /IM discord.exe >nul 2>nul
    pushd "%VC%"
    call pnpm build
    if errorlevel 1 (
        popd
        echo [AVISO] pnpm build fallo. Recompila manualmente.
        goto :manual
    )
    call pnpm inject
    popd
)

:manual
echo.
echo Si hace falta, recompila y aplica manualmente:
if defined VC echo    cd /d "%VC%"
if defined VC echo    pnpm build
if defined VC echo    pnpm inject
echo.
pause
exit /b 0
