@echo off
setlocal EnableExtensions
title ycord rendimiento - instalador
color 0B

set "ROOT=%~dp0"
set "THEME_SRC=%ROOT%theme\ycord.theme.css"
set "PLUGIN_SRC=%ROOT%plugin\ycord\index.tsx"
set "PLUGIN_README=%ROOT%plugin\ycord\README.md"

echo.
echo   ============================================
echo    ycord - rendimiento para Discord
echo    tema + plugin + instalador
echo   ============================================
echo.

call :require "%THEME_SRC%" "theme\ycord.theme.css"
if errorlevel 1 goto :fail
call :require "%PLUGIN_SRC%" "plugin\ycord\index.tsx"
if errorlevel 1 goto :fail

rem ---------- localizar Vencord ----------
set "VC=%~1"
if not defined VC set "VC=%VENCORD_DIR%"

if not defined VC if exist "%USERPROFILE%\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Vencord"
if not defined VC if exist "%USERPROFILE%\Documents\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Documents\Vencord"
if not defined VC if exist "%USERPROFILE%\Desktop\Vencord\src\Vencord.ts" set "VC=%USERPROFILE%\Desktop\Vencord"
if not defined VC if exist "C:\Vencord\src\Vencord.ts" set "VC=C:\Vencord"
if not defined VC if exist "%LOCALAPPDATA%\Vencord\src\Vencord.ts" set "VC=%LOCALAPPDATA%\Vencord"

if not defined VC (
    echo No encontre el codigo fuente de Vencord automaticamente.
    echo.
    choice /C SN /N /M "Clonar Vencord en %USERPROFILE%\Vencord ahora? [S/N] "
    if errorlevel 2 goto :askpath
    where git >nul 2>nul
    if errorlevel 1 (
        echo.
        echo [ERROR] Git no esta en PATH. Instala Git desde https://git-scm.com
        goto :fail
    )
    if exist "%USERPROFILE%\Vencord" (
        echo.
        echo [ERROR] "%USERPROFILE%\Vencord" ya existe pero no es un Vencord valido.
        goto :askpath
    )
    echo.
    echo Clonando Vencord...
    git clone https://github.com/Vendicated/Vencord "%USERPROFILE%\Vencord"
    if errorlevel 1 (
        echo.
        echo [ERROR] git clone fallo.
        goto :fail
    )
    set "VC=%USERPROFILE%\Vencord"
    goto :havevc
)

goto :havevc

:askpath
set /p "VC=Ruta de la carpeta Vencord: "

:havevc
if not defined VC (
    echo.
    echo [ERROR] No se indico la ruta de Vencord.
    goto :fail
)

if not exist "%VC%\src\Vencord.ts" (
    echo.
    echo [ERROR] No existe "%VC%\src\Vencord.ts"
    echo Pasa la ruta correcta: install-ycord.cmd "C:\ruta\Vencord"
    goto :fail
)

rem ---------- tema ----------
set "THEMES=%APPDATA%\Vencord\themes"
if not exist "%THEMES%" mkdir "%THEMES%" >nul 2>nul
if not exist "%THEMES%" (
    echo [ERROR] No se pudo crear "%THEMES%"
    goto :fail
)

copy /Y "%THEME_SRC%" "%THEMES%\ycord.theme.css" >nul
if errorlevel 1 (
    echo [ERROR] No se pudo copiar el tema.
    goto :fail
)
echo [OK] Tema instalado en "%THEMES%\ycord.theme.css"

rem ---------- plugin ----------
set "PLUGIN_DIR=%VC%\src\userplugins\ycord"
if not exist "%VC%\src\userplugins" mkdir "%VC%\src\userplugins" >nul 2>nul
if not exist "%PLUGIN_DIR%" mkdir "%PLUGIN_DIR%" >nul 2>nul
if not exist "%PLUGIN_DIR%" (
    echo [ERROR] No se pudo crear "%PLUGIN_DIR%"
    goto :fail
)

copy /Y "%PLUGIN_SRC%" "%PLUGIN_DIR%\index.tsx" >nul
if errorlevel 1 (
    echo [ERROR] No se pudo copiar el plugin.
    goto :fail
)
if exist "%PLUGIN_README%" copy /Y "%PLUGIN_README%" "%PLUGIN_DIR%\README.md" >nul
echo [OK] Plugin instalado en "%PLUGIN_DIR%\index.tsx"

rem ---------- dependencias ----------
where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Node.js no esta en PATH.
    echo Instala Node.js 22 o superior desde https://nodejs.org
    goto :fail
)

where npm >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] npm no esta en PATH. Reinstala Node.js.
    goto :fail
)

where pnpm >nul 2>nul
if errorlevel 1 (
    echo.
    echo pnpm no esta instalado.
    choice /C SN /N /M "Instalar pnpm ahora con npm? [S/N] "
    if errorlevel 2 (
        echo.
        echo [ERROR] pnpm es necesario para compilar Vencord.
        echo Instala con: npm install -g pnpm
        goto :fail
    )
    call npm install -g pnpm
    if errorlevel 1 (
        echo.
        echo [ERROR] No se pudo instalar pnpm.
        goto :fail
    )
)

where pnpm >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] pnpm sigue sin estar en PATH. Abre una consola nueva y vuelve a ejecutar.
    goto :fail
)

echo.
echo [1/2] Preparando dependencias...
pushd "%VC%"
if not exist "node_modules" (
    call pnpm install
    if errorlevel 1 (
        popd
        echo [ERROR] pnpm install fallo.
        goto :fail
    )
) else (
    echo [OK] node_modules ya existe.
)

echo.
echo [2/2] Compilando Vencord con el plugin ycord...
call pnpm build
if errorlevel 1 (
    popd
    echo [ERROR] pnpm build fallo.
    goto :fail
)
popd
echo [OK] Vencord compilado.

rem ---------- aplicar en Discord ----------
echo.
echo Plugin compilado. Para aplicarlo en Discord Desktop hay que reiniciar el cliente.
choice /C SN /N /M "Cerrar Discord y ejecutar pnpm inject ahora? [S/N] "
if errorlevel 2 goto :manual

echo.
echo Cerrando Discord...
taskkill /F /IM Discord.exe >nul 2>nul
taskkill /F /IM discord.exe >nul 2>nul
echo Ejecutando pnpm inject...
pushd "%VC%"
call pnpm inject
set "INJECT_CODE=%errorlevel%"
popd

if not "%INJECT_CODE%"=="0" (
    echo.
    echo [AVISO] pnpm inject no termino correctamente.
    echo Cierra Discord y ejecuta manualmente:
    echo    cd /d "%VC%"
    echo    pnpm inject
)
goto :done

:manual
echo.
echo Cuando quieras aplicar el plugin:
echo    cd /d "%VC%"
echo    pnpm inject

:done
echo.
echo   ============================================
echo    Listo.
echo.
echo    Tema:   "%THEMES%\ycord.theme.css"
echo    Plugin: "%PLUGIN_DIR%\index.tsx"
echo.
echo    Reinicia Discord y activa:
echo      Ajustes - Vencord - Plugins - ycord   (requiere reinicio)
echo      Ajustes - Vencord - Themes - ycord
echo.
echo    Si usas AlwaysAnimate o NoTypingAnimation,
echo    desactivalos: ycord ya aplica esos ajustes.
echo   ============================================
echo.
pause
exit /b 0

:require
if not exist "%~1" (
    echo [ERROR] Falta %~2
    exit /b 1
)
exit /b 0

:fail
echo.
pause
exit /b 1
