# ycord · rendimiento para Discord

Paquete para **optimizar Discord** con Vencord. No tiene relación con ninguna
app externa: son dos entregables independientes, ambos llamados **ycord**.

- **Tema `ycord`** — quita el blur, las animaciones CSS, las sombras grandes y
  las decoraciones. Deja la interfaz opaca y plana.
- **Plugin `ycord`** — corta las animaciones internas de Discord, los eventos de
  typing y, opcionalmente, la presencia y las analíticas.

Ambos están pensados para funcionar juntos. Ninguno envía datos, hace peticiones
de red ni carga fuentes o imágenes externas.

## Contenido

```
vencord/
  theme/
    ycord.theme.css
  plugin/
    ycord/
      index.tsx
      README.md
  install-ycord.cmd
  uninstall-ycord.cmd
```

## Qué optimiza exactamente

### Tema

- **`backdrop-filter: none` global.** Es el efecto más caro de Discord: obliga a
  leer y desenfocar el fondo en cada frame.
- **Animaciones y transiciones a ~0.** Se conservan los spinners de carga.
- **`will-change: auto`.** Evita capas GPU persistentes.
- **Decoraciones ocultas.** Avatares animados, efectos de perfil, placas y
  decoraciones dejan de decodificarse y pintarse.
- **Sombras grandes eliminadas** en menús, modales y tooltips.
- **Superficies opacas** y paleta oscura plana: menos compositing.
- **Scrollbars finas** y sin track.
- **Cero `@import`, cero fuentes externas, cero imágenes.**

### Plugin

- **`canAnimate: false`** en todos los componentes que lo consultan: apaga
  avatares animados, GIFs, emojis, banners y decoraciones de una sola vez.
- **Animación de «escribiendo…»** desactivada.
- **Emojis de estado, banners, gradientes de rol y placas animadas** detenidos.
- **Eventos de typing ignorados** para evitar re-renders en servidores grandes.
- **Presencia congelable** (opcional).
- **Analíticas de Discord anuladas** (si el módulo existe).

## Instalación rápida (CMD)

Requisitos:

- Windows.
- Node.js 22 o superior.
- Git (solo si el instalador tiene que clonar Vencord).
- Vencord instalado **desde el código fuente**.

Abre CMD en esta carpeta y ejecuta:

```bat
install-ycord.cmd
```

Si Vencord está en otra ruta:

```bat
install-ycord.cmd "D:\Desarrollo\Vencord"
```

El instalador:

1. Copia el tema a `%APPDATA%\Vencord\themes\ycord.theme.css`.
2. Copia el plugin a `Vencord\src\userplugins\ycord\`.
3. Clona Vencord si no lo encuentra (con confirmación).
4. Instala `pnpm` con npm si falta.
5. Ejecuta `pnpm build`.
6. Ofrece cerrar Discord y ejecutar `pnpm inject`.

Después, reinicia Discord y activa:

- **Ajustes → Vencord → Plugins → ycord**
- **Ajustes → Vencord → Themes → ycord**

El plugin necesita **reiniciar Discord** al activarlo para aplicar los parches.

## Instalación manual

### Tema

Copia `theme\ycord.theme.css` a:

```text
%APPDATA%\Vencord\themes\ycord.theme.css
```

Luego, en Discord: **Ajustes → Vencord → Themes → Local Themes → Load missing
Themes** y activa **ycord**.

### Plugin

1. Copia la carpeta `plugin\ycord` dentro de `Vencord\src\userplugins\`.
2. Compila e inyecta:

```bat
cd /d "C:\ruta\Vencord"
pnpm build
pnpm inject
```

3. Reinicia Discord y activa **ycord** en Plugins.

## Ajustes del plugin

- **Ignorar eventos de «escribiendo…»** — activado.
- **Anular eventos analíticos** — activado; requiere reiniciar.
- **Congelar presencia** — desactivado; opcional y agresivo.

## Ajustes recomendados en Discord

Para exprimir aún más el rendimiento, además del paquete:

1. **Ajustes → Avanzado → Aceleración por hardware:** activada.
2. **Ajustes → Texto e imágenes → Reproducir GIF automáticamente:** desactivado
   (el plugin ya lo cubre, pero el ajuste nativo es más persistente).
3. **Ajustes → Avanzado → Superposición:** desactivada si no la usas.
4. Cierra Discord cuando no lo estés usando; el cliente mantiene procesos en
   segundo plano.
5. Evita temas con blur, transparencia o `backdrop-filter`.

## Compatibilidad

Desactiva estos plugins de Vencord si los tienes:

- **AlwaysAnimate** — fuerza justo lo que ycord desactiva.
- **NoTypingAnimation** — duplica el parche de los puntos de typing.
- Cualquier plugin que añada animaciones, efectos de perfil o decoraciones.

## Desinstalar

```bat
uninstall-ycord.cmd
```

El desinstalador borra el tema, borra `src\userplugins\ycord` y ofrece
recompilar para quitarlo del bundle.

## Resultado esperado

El mayor ahorro viene de tres frentes:

- **GPU:** sin `backdrop-filter`, sin capas `will-change`, sin sombras grandes.
- **CPU:** sin animaciones de avatares, GIFs, emojis, typing y gradientes.
- **Eventos:** menos dispatches de typing (y presencia si se activa).

No se puede prometer un número exacto de MB o FPS: depende de la GPU, del número
de servidores, de los canales abiertos y de los plugins que tengas instalados.

## Aviso

Vencord y los client mods no están oficialmente soportados por Discord. Úsalo
bajo tu responsabilidad y solo en tu propia cuenta.
